<?php
class BookModel {
    private $db;

    public function __construct($db) {
        $this->db = $db;
    }

    public function getAllBooks() {
        $stmt = $this->db->prepare("SELECT * FROM books");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function searchBooks($query) {
        $query = "%$query%";
        $stmt = $this->db->prepare("SELECT * FROM books WHERE title LIKE ? OR author LIKE ? OR isbn LIKE ?");
        $stmt->execute([$query, $query, $query]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function addBook($title, $author, $isbn, $year) {
        $stmt = $this->db->prepare("INSERT INTO books (title, author, isbn, published_year) VALUES (?, ?, ?, ?)");
        $stmt->execute([$title, $author, $isbn, $year]);
        return $stmt->rowCount() > 0;
    }

    public function getBookById($id) {
        $stmt = $this->db->prepare("SELECT * FROM books WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public function updateBook($id, $title, $author, $isbn, $year) {
        $stmt = $this->db->prepare("UPDATE books SET title = ?, author = ?, isbn = ?, published_year = ? WHERE id = ?");
        $stmt->execute([$title, $author, $isbn, $year, $id]);
        return $stmt->rowCount() > 0;
    }

    public function deleteBook($id) {
        $stmt = $this->db->prepare("DELETE FROM books WHERE id = ?");
        $stmt->execute([$id]);
        return $stmt->rowCount() > 0;
    }

    public function issueBook($bookId, $userId) {
        $stmt = $this->db->prepare("SELECT available FROM books WHERE id = ?");
        $stmt->execute([$bookId]);
        if ($stmt->fetchColumn() == 1) {
            $issueDate = date('Y-m-d');
            $stmt = $this->db->prepare("INSERT INTO issued_books (book_id, user_id, issue_date) VALUES (?, ?, ?)");
            $stmt->execute([$bookId, $userId, $issueDate]);
            $stmt = $this->db->prepare("UPDATE books SET available = 0 WHERE id = ?");
            $stmt->execute([$bookId]);
            return true;
        }
        return false;
    }

    public function returnBook($issuedId) {
        $returnDate = date('Y-m-d');
        $stmt = $this->db->prepare("UPDATE issued_books SET return_date = ? WHERE id = ?");
        $stmt->execute([$returnDate, $issuedId]);
        $stmt = $this->db->prepare("SELECT book_id FROM issued_books WHERE id = ?");
        $stmt->execute([$issuedId]);
        $bookId = $stmt->fetchColumn();
        $stmt = $this->db->prepare("UPDATE books SET available = 1 WHERE id = ?");
        $stmt->execute([$bookId]);
        return true;
    }

    public function getIssuedBooks() {
        $stmt = $this->db->prepare("SELECT ib.id, b.title, b.author, u.username, ib.issue_date, ib.return_date
            FROM issued_books ib
            JOIN books b ON ib.book_id = b.id
            JOIN users u ON ib.user_id = u.id
            ORDER BY ib.issue_date DESC");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function getDashboardStats() {
        $stmt = $this->db->prepare("SELECT COUNT(*) AS total_books FROM books");
        $stmt->execute();
        $totalBooks = $stmt->fetchColumn();

        $stmt = $this->db->prepare("SELECT COUNT(*) AS available_books FROM books WHERE available = 1");
        $stmt->execute();
        $availableBooks = $stmt->fetchColumn();

        $issuedBooks = $totalBooks - $availableBooks;

        return ['total' => $totalBooks, 'available' => $availableBooks, 'issued' => $issuedBooks];
    }
}
?>