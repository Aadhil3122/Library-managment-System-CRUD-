<?php
function register_view($error = null) {
    echo '
        <h2>Register</h2>
        ' . ($error ? '<div class="error">' . $error . '</div>' : '') . '
        <form method="POST" action="index.php?action=register">
            <input type="text" name="username" placeholder="Username" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <input type="password" name="confirm_password" placeholder="Confirm Password" required>
            <button type="submit">Register</button>
        </form>
        <a href="index.php?action=login">Back to Login</a>
    ';
}

function login_view($error = null) {
    
    $books = [
        ['id' => 1, 'title' => 'Book One', 'author' => 'Author A'],
        ['id' => 2, 'title' => 'Book Two', 'author' => 'Author B'],
        ['id' => 3, 'title' => 'Book Three', 'author' => 'Author C'],
    ];

    echo '
        <div class="login-box">
            <h2>UOVT Library System</h2>
            <h2>Login</h2>
            ' . ($error ? '<div class="error">' . $error . '</div>' : '') . '
            <form method="POST" action="index.php?action=login">
                <input type="text" name="username" placeholder="Username" required>
                <input type="password" name="password" placeholder="Password" required>
                <button type="submit">Login</button>
            </form>
            <p>If you don\'t have an account, <a href="index.php?action=register">register here</a></p>

            
    ';
}

function attendance_view($attendance) {
    echo '
        <h2>Attendance</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Username</th>
                    <th>Login Time</th>
                </tr>
            </thead>
            <tbody>
                ';
    foreach ($attendance as $row) {
        echo '<tr><td>' . htmlspecialchars($row['id']) . '</td><td>' . htmlspecialchars($row['username']) . '</td><td>' . htmlspecialchars($row['login_time']) . '</td></tr>';
    }
    echo '
            </tbody>
        </table>
        <a href="index.php?action=dashboard">Back to Dashboard</a>
    ';
}
?>