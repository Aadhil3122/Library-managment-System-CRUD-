<?php
function dashboard_view($stats) {
    echo '
        <h2>Dashboard</h2>
        <div class="stat-card total">
            <h3>Total Books</h3>
            <p>' . $stats['total'] . '</p>
        </div>
        <div class="stat-card available">
            <h3>Available Books</h3>
            <p>' . $stats['available'] . '</p>
        </div>
        <div class="stat-card issued">
            <h3>Issued Books</h3>
            <p>' . $stats['issued'] . '</p>
        </div>
        <br>
        <a href="index.php?action=books">Manage Books</a>
        <a href="index.php?action=attendance">View Attendance</a>
        <a href="index.php?action=issuedBooks">View Issued Books</a>
        <a href="index.php?action=logout" class="btn-danger">Logout</a>
    ';
}

function books_list_view($books) {
    echo '
        <h2>Books List</h2>
        <form method="GET" action="index.php" class="form-inline">
            <input type="hidden" name="action" value="searchBooks">
            <input type="text" name="query" placeholder="Search by title, author, or ISBN..." required>
            <button type="submit">Search</button>
        </form>
        <a href="index.php?action=addBook" class="btn-success">Add Book</a>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Title</th>
                    <th>Author</th>
                    <th>ISBN</th>
                    <th>Year</th>
                    <th>Available</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                ';
    foreach ($books as $book) {
        echo '<tr><td>' . htmlspecialchars($book['id']) . '</td><td>' . htmlspecialchars($book['title']) . '</td><td>' . htmlspecialchars($book['author']) . '</td><td>' . htmlspecialchars($book['isbn']) . '</td><td>' . htmlspecialchars($book['published_year']) . '</td><td>' . ($book['available'] ? 'Yes' : 'No') . '</td><td>';
        if ($book['available']) {
            echo '<form method="POST" action="index.php?action=issueBook" style="display:inline;"><input type="hidden" name="book_id" value="' . $book['id'] . '"><button type="submit" class="btn-info">Issue</button></form> ';
        }
        echo '<a href="index.php?action=editBook&id=' . $book['id'] . '" class="btn-warning">Edit</a> ';
        echo '<a href="index.php?action=deleteBook&id=' . $book['id'] . '" class="btn-danger" onclick="return confirm(\'Are you sure?\')">Delete</a></td></tr>';
    }
    echo '
            </tbody>
        </table>
        <a href="index.php?action=dashboard">Back to Dashboard</a>
    ';
}

function add_book_view() {
    echo '
        <h2>Add Book</h2>
        <form method="POST" action="index.php?action=saveBook">
            <input type="text" name="title" placeholder="Title" required>
            <input type="text" name="author" placeholder="Author" required>
            <input type="text" name="isbn" placeholder="ISBN" required>
            <input type="number" name="year" placeholder="Year" required>
            <button type="submit">Save</button>
        </form>
        <a href="index.php?action=books">Back to Books</a>
    ';
}

function edit_book_view($book) {
    echo '
        <h2>Edit Book</h2>
        <form method="POST" action="index.php?action=updateBook">
            <input type="hidden" name="id" value="' . htmlspecialchars($book['id']) . '">
            <input type="text" name="title" value="' . htmlspecialchars($book['title']) . '" required>
            <input type="text" name="author" value="' . htmlspecialchars($book['author']) . '" required>
            <input type="text" name="isbn" value="' . htmlspecialchars($book['isbn']) . '" required>
            <input type="number" name="year" value="' . htmlspecialchars($book['published_year']) . '" required>
            <button type="submit">Update</button>
        </form>
        <a href="index.php?action=books">Back to Books</a>
    ';
}

function issued_books_view($issuedBooks) {
    echo '
        <h2>Issued Books</h2>
        <table>
            <thead>
                <tr>
                    <th>Title</th>
                    <th>Author</th>
                    <th>Borrower</th>
                    <th>Issue Date</th>
                    <th>Return Date</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                ';
    foreach ($issuedBooks as $book) {
        $status = $book['return_date'] ? 'Returned' : 'Borrowed';
        echo '<tr><td>' . htmlspecialchars($book['title']) . '</td><td>' . htmlspecialchars($book['author']) . '</td><td>' . htmlspecialchars($book['username']) . '</td><td>' . htmlspecialchars($book['issue_date']) . '</td><td>' . htmlspecialchars($book['return_date'] ?? 'Not Returned') . '</td><td>' . $status . '</td><td>';
        if (!$book['return_date']) {
            echo '<a href="index.php?action=returnBook&id=' . $book['id'] . '" class="btn-success">Return</a>';
        }
        echo '</td></tr>';
    }
    echo '
            </tbody>
        </table>
        <a href="index.php?action=dashboard">Back to Dashboard</a>
    ';
}
?>