<?php
require_once 'models/UserModel.php';
require_once 'views/user_view.php';

class UserController {
    private $model;

    public function __construct($db) {
        $this->model = new UserModel($db);
    }

    public function register() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = $_POST['username'];
            $email = $_POST['email'];
            $password = $_POST['password'];
            $confirmPassword = $_POST['confirm_password'];
            if ($password === $confirmPassword) {
                if ($this->model->register($username, $email, $password)) {
                    header("Location: index.php?action=login");
                } else {
                    $error = "Username or email already exists";
                    register_view($error);
                }
            } else {
                $error = "Passwords do not match";
                register_view($error);
            }
        } else {
            register_view();
        }
    }

    public function login() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $username = $_POST['username'];
            $password = $_POST['password'];
            $user = $this->model->login($username, $password);
            if ($user) {
                $_SESSION['user'] = $user;
                $this->model->recordAttendance($user['id']);
                header("Location: index.php?action=dashboard");
            } else {
                $error = "Invalid credentials";
                login_view($error);
            }
        } else {
            login_view();
        }
    }

    public function logout() {
        session_destroy();
        header("Location: index.php?action=login");
    }

    public function attendance() {
        $attendance = $this->model->getAttendance();
        attendance_view($attendance);
    }
}
?>