<?php
require_once 'models/BookModel.php';
require_once 'views/book_view.php';

class BookController {
    private $model;

    public function __construct($db) {
        $this->model = new BookModel($db);
    }

    public function dashboard() {
        $stats = $this->model->getDashboardStats();
        dashboard_view($stats);
    }

    public function index() {
        $books = $this->model->getAllBooks();
        books_list_view($books);
    }

    public function searchBooks($query) {
        $books = $this->model->searchBooks($query);
        books_list_view($books);
    }

    public function addBookForm() {
        add_book_view();
    }

    public function saveBook($data) {
        $title = $data['title'];
        $author = $data['author'];
        $isbn = $data['isbn'];
        $year = $data['year'];
        $this->model->addBook($title, $author, $isbn, $year);
        header("Location: index.php?action=books");
    }

    public function editBookForm($id) {
        $book = $this->model->getBookById($id);
        edit_book_view($book);
    }

    public function updateBook($data) {
        $id = $data['id'];
        $title = $data['title'];
        $author = $data['author'];
        $isbn = $data['isbn'];
        $year = $data['year'];
        $this->model->updateBook($id, $title, $author, $isbn, $year);
        header("Location: index.php?action=books");
    }

    public function deleteBook($id) {
        $this->model->deleteBook($id);
        header("Location: index.php?action=books");
    }

    public function issueBook($data) {
        $bookId = $data['book_id'];
        $userId = $_SESSION['user']['id'];
        $this->model->issueBook($bookId, $userId);
        header("Location: index.php?action=issuedBooks");
    }

    public function returnBook($id) {
        $this->model->returnBook($id);
        header("Location: index.php?action=issuedBooks");
    }

    public function issuedBooks() {
        $issuedBooks = $this->model->getIssuedBooks();
        issued_books_view($issuedBooks);
    }
}
?>